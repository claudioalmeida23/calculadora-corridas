/* script.js - optimized */
document.getElementById("ano").textContent=new Date().getFullYear();
const origemInput=document.getElementById('origem'),destinoInput=document.getElementById('destino'),
micOrigem=document.getElementById('micOrigem'),micDestino=document.getElementById('micDestino'),
btnRoute=document.getElementById('btnRoute'),btnClearRoute=document.getElementById('btnClearRoute'),
kmInput=document.getElementById('km'),mediaInput=document.getElementById('media'),
gasolinaInput=document.getElementById('gasolina'),cobrarInput=document.getElementById('cobrar'),
btnCalc=document.getElementById('btnCalc'),btnClearAll=document.getElementById('btnClearAll'),
resultado=document.getElementById('resultado');
const map=L.map('map').setView([-23.5505,-46.6333],12);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{attribution:'© OpenStreetMap'}).addTo(map);
let routeLayer=null,markers=[];
function showResult(html){resultado.hidden=false;resultado.innerHTML=html}
function hideResult(){resultado.hidden=true;resultado.innerHTML=''}
function fmt(v){return'R$ '+Number(v).toFixed(2).replace('.',',')}
async function geocode(q){try{const r=await fetch('https://nominatim.openstreetmap.org/search?format=json&q='+encodeURIComponent(q));const j=await r.json();if(!j.length) return null;return{lat:+j[0].lat,lon:+j[0].lon}}catch(e){return null}}
async function rota(a,b){const url=`https://router.project-osrm.org/route/v1/driving/${a.lon},${a.lat};${b.lon},${b.lat}?overview=full&geometries=geojson`;const r=await fetch(url);const j=await r.json();return j.routes&&j.routes[0]}
function aplicarRota(r,a,b,mult){const kmFinal=(r.distance/1000)*mult;kmInput.value=kmFinal.toFixed(2);if(routeLayer)map.removeLayer(routeLayer);markers.forEach(m=>map.removeLayer(m));markers=[];routeLayer=L.geoJSON(r.geometry).addTo(map);markers.push(L.marker([a.lat,a.lon]).addTo(map));markers.push(L.marker([b.lat,b.lon]).addTo(map));map.fitBounds(routeLayer.getBounds())}
btnRoute.onclick=async()=>{hideResult();if(!origemInput.value||!destinoInput.value)return alert('Informe origem e destino.');btnRoute.disabled=true;const a=await geocode(origemInput.value),b=await geocode(destinoInput.value);if(!a||!b){alert('Endereço não encontrado');btnRoute.disabled=false;return}const r=await rota(a,b);if(!r){alert('Erro ao calcular rota');btnRoute.disabled=false;return}const escolha=confirm('Após chegar ao destino, você vai voltar para a origem?\n\nOK = Ida e volta\nCancelar = Somente ida');aplicarRota(r,a,b,escolha?2:1);btnRoute.disabled=false};
btnClearRoute.onclick=()=>{origemInput.value='';destinoInput.value='';kmInput.value='';hideResult();if(routeLayer)map.removeLayer(routeLayer);markers.forEach(m=>map.removeLayer(m));markers=[]};
btnCalc.onclick=()=>{hideResult();const km=+kmInput.value,media=+mediaInput.value,gasolina=+gasolinaInput.value,cobrar=+cobrarInput.value;if(!km)return alert('Calcule o KM primeiro');if(!media||!gasolina||!cobrar)return alert('Preencha todos os campos');const litros=km/media,custo=litros*gasolina,custoKm=custo/km,valorKm=cobrar/km,lucro=cobrar-custo;showResult(`<strong>CUSTOS</strong><br>⛽ Litros: <span class="kv">${litros.toFixed(2)}</span><br>💰 Combustível: <span class="kv">${fmt(custo)}</span><br>📏 Custo/km: <span class="kv">${fmt(custoKm)}</span><br><br><strong>RECEITA</strong><br>💵 Total cobrado: <span class="kv">${fmt(cobrar)}</span><br>🚗 Valor/km: <span class="kv">${fmt(valorKm)}</span><br><br><strong>RESULTADO</strong><br>${lucro>=0?'✅ Lucro':'❌ Prejuízo'}: <span class="kv ${lucro<0?'alert':''}">${fmt(lucro)}</span>`)}
btnClearAll.onclick=()=>{origemInput.value='';destinoInput.value='';kmInput.value='';mediaInput.value='';gasolinaInput.value='';cobrarInput.value='';hideResult();if(routeLayer)map.removeLayer(routeLayer);markers.forEach(m=>map.removeLayer(m));markers=[]};

/* Voice recognition */
function iniciarVoz(botao,input){if(!('webkitSpeechRecognition' in window)){alert('Seu navegador não suporta reconhecimento de voz.');return}const rec=new webkitSpeechRecognition();rec.lang='pt-BR';rec.interimResults=false;rec.maxAlternatives=1;botao.classList.add('active');rec.start();rec.onresult=(e)=>{input.value=e.results[0][0].transcript;botao.classList.remove('active')};rec.onerror=()=>{botao.classList.remove('active');alert('Erro no reconhecimento de voz.')};rec.onend=()=>{botao.classList.remove('active')}}
micOrigem.onclick=()=>iniciarVoz(micOrigem,origemInput);micDestino.onclick=()=>iniciarVoz(micDestino,destinoInput);

/* accessibility: enter to search */
origemInput.addEventListener('keydown',e=>{if(e.key==='Enter'){btnRoute.click()}});destinoInput.addEventListener('keydown',e=>{if(e.key==='Enter'){btnRoute.click()}})
