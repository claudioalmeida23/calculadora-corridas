/* Simple service worker for offline shell */
const CACHE_NAME='caminho-certo-v1';
const RESOURCES=['/','/index.html','/style.css','/script.js'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE_NAME).then(c=>c.addAll(RESOURCES)))});
self.addEventListener('activate',e=>{e.waitUntil(self.clients.claim())});
self.addEventListener('fetch',e=>{e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request)))});
